<template>
    <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 16 16"><path fill="currentColor" d="M14.004 3a1 1 0 0 1 1 1v8a1 1 0 1 1-2 0V4a1 1 0 0 1 1-1M4.297 4.293a1 1 0 0 1 1.414 1.414L4.418 7h6.586a1 1 0 1 1 0 2H4.418l1.293 1.293a1 1 0 1 1-1.414 1.414L.59 8z"></path></svg>
</template>