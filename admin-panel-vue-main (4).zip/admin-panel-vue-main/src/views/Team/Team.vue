<template>
  <div class="space-y-6">
    <h1 class="text-2xl sm:text-3xl font-bold text-gray-900">Команда</h1>
    
    <div class="bg-white rounded-lg shadow border border-gray-200 p-6">
      <p class="text-gray-600">Страница команды в разработке</p>
    </div>
  </div>
</template>

<script setup>
</script>

