<template>
  <div class="space-y-6">
    <ProductsTable />
  </div>
</template>

<script setup>
import ProductsTable from './components/ProductsTable.vue'
</script>

