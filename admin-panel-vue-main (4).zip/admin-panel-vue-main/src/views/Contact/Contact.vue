<template>
  <div class="space-y-6">
    <h1 class="text-2xl sm:text-3xl font-bold text-gray-900">Связать</h1>
    
    <div class="bg-white rounded-lg shadow border border-gray-200 p-6">
      <div class="max-w-3xl">
        <h2 class="text-xl font-semibold text-gray-900 mb-4">Свяжитесь с нами</h2>
        
        <div class="space-y-6">
          <div>
            <h3 class="text-lg font-medium text-gray-900 mb-2">Электронная почта</h3>
            <p class="text-gray-600">
              Напишите нам на: <a href="mailto:support@example.com" class="text-blue-600 hover:text-blue-700">support@example.com</a>
            </p>
          </div>
          
          <div>
            <h3 class="text-lg font-medium text-gray-900 mb-2">Телефон</h3>
            <p class="text-gray-600">
              Позвоните нам: <a href="tel:+79991234567" class="text-blue-600 hover:text-blue-700">+7 (999) 123-45-67</a>
            </p>
          </div>
          
          <div>
            <h3 class="text-lg font-medium text-gray-900 mb-2">Время работы</h3>
            <p class="text-gray-600">
              Пн-Пт: 9:00 - 18:00<br>
              Сб-Вс: Выходной
            </p>
          </div>
          
          <div>
            <h3 class="text-lg font-medium text-gray-900 mb-2">Адрес</h3>
            <p class="text-gray-600">
              г. Москва, ул. Примерная, д. 1<br>
              Офис 101
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
</script>

