<template>
  <div class="about">
    <h1>О проекте</h1>
    <p>Информация о проекте</p>
  </div>
</template>

<script setup>
</script>

<style scoped>
.about {
  padding: 2rem;
  text-align: center;
}

h1 {
  color: #42b883;
  margin-bottom: 1rem;
}
</style>

