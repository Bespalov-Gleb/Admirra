<template>
  <div class="space-y-6">
    <h1 class="text-2xl sm:text-3xl font-bold text-gray-900">Помощь</h1>
    
    <div class="bg-white rounded-lg shadow border border-gray-200 p-6">
      <div class="max-w-3xl">
        <h2 class="text-xl font-semibold text-gray-900 mb-4">Часто задаваемые вопросы</h2>
        
        <div class="space-y-4">
          <div class="border-b border-gray-200 pb-4">
            <h3 class="text-lg font-medium text-gray-900 mb-2">Как создать новый проект?</h3>
            <p class="text-gray-600">
              Для создания нового проекта нажмите на кнопку "Добавить новый проект" в верхней части страницы.
            </p>
          </div>
          
          <div class="border-b border-gray-200 pb-4">
            <h3 class="text-lg font-medium text-gray-900 mb-2">Как просмотреть статистику?</h3>
            <p class="text-gray-600">
              Перейдите в раздел "Дашборд" в боковом меню, чтобы просмотреть общую статистику по всем проектам.
            </p>
          </div>
          
          <div class="border-b border-gray-200 pb-4">
            <h3 class="text-lg font-medium text-gray-900 mb-2">Как изменить настройки аккаунта?</h3>
            <p class="text-gray-600">
              В разделе "Настройки" вы можете изменить данные своего аккаунта, пароль и другие параметры.
            </p>
          </div>
          
          <div class="pb-4">
            <h3 class="text-lg font-medium text-gray-900 mb-2">Как экспортировать данные?</h3>
            <p class="text-gray-600">
              На страницах с таблицами данных используйте кнопку "Export data" для экспорта информации.
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
</script>

